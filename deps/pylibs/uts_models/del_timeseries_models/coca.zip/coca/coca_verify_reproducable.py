"""
I do not change hyperparameters and configs except the printing and some unrelated statements.

"""

import random
import sys

import numpy
import torch

sys.path.append("./")
from merlion.utils import TimeSeries

from dataloader.dataset import data_generator1
from pysearchlib.utils.util_pytorch import summary_dataset
from timeseries_models.coca.coca_config import COCAConf
from timeseries_models.coca.coca_model import COCAModel
from ts_datasets.anomaly import IOpsCompetition


def enable_numpy_reproduce(seed=42):
    random.seed(seed)
    numpy.random.seed(seed)


def enable_pytorch_reproduciable(seed=0):
    """
    For reproducible results.

    Parameters
    ----------
    seed :

    Returns
    -------

    """
    # https://pytorch.org/docs/stable/notes/randomness.html
    torch.manual_seed(seed)
    random.seed(seed)
    numpy.random.seed(seed)


enable_numpy_reproduce(1)
enable_pytorch_reproduciable(1)
conf = COCAConf()
conf.batch_size = 512
idx = -3
dt = IOpsCompetition()

time_series, meta_data = dt[idx]
train_data = TimeSeries.from_pd(time_series[meta_data.trainval])
test_data = TimeSeries.from_pd(time_series[~meta_data.trainval])
train_labels = TimeSeries.from_pd(meta_data.anomaly[meta_data.trainval])
test_labels = TimeSeries.from_pd(meta_data.anomaly[~meta_data.trainval])
train_dl, val_dl, test_dl, test_anomaly_window_num = data_generator1(train_data, test_data, train_labels, test_labels,
                                                                     conf)
summary_dataset(train_dl)
summary_dataset(val_dl)
summary_dataset(test_dl)
coca = COCAModel(conf)
coca.fit(train_dl)
score = coca.score_coca(val_dl)
# threshold (percentile) between [0.001, 0.3]
# _percentiles = np.arange(1, 301) / 1e3
metrics = coca.report_metrics_coca(val_dl, test_dl)
# Assure the metrics is absolutely equal to COCA source: https://github.com/ruiking04/COCA
assert metrics["valid_affiliation_precision"] == 0.9882697947214076
assert metrics["valid_affiliation_recall"] == 0.49824046920821113
assert metrics["test_affiliation_recall"] == 0.41551757819907786
assert metrics["test_affiliation_precision"] == 0.6605439430607345

# threshold (percentile) between [0.000, 10]
# np.arange(0.0, 10.5, 0.5)
coca.report_metrics(val_dl, test_dl)
# Final result: {'valid_affiliation_f1': 0.8222762059566984, 'valid_affiliation_precision': 0.7449194534205834,
# 'valid_affiliation_recall': 0.9175610636880414, 'test_affiliation_f1': 0.6959826332769921,
# 'test_affiliation_precision': 0.5759657981468603, 'test_affiliation_recall': 0.8791821571859323, 'time_app_start':
# -1, 'time_app_end': -1, 'time_train_start': -1, 'time_train_end': -1, 'time_eval_start': 1680336545082517000,
# 'time_eval_end': 1680336545756253000, 'elapsed_train': 0.0, 'default': 0.6959826332769921}
